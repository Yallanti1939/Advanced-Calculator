# 🧮 Advanced Python Calculator

A beginner-friendly Python GUI Calculator built with `Tkinter`. Includes basic and advanced arithmetic operations, plus a history panel.

## 🚀 Features
- Simple GUI (Tkinter)
- Basic operations: +, -, ×, ÷
- Advanced functions: 
  - Square Root (√)
  - Power (^)
  - Modulus (%)
- Error Handling
- Calculation History Display

## 🖥️ Screenshots
![screenshot](screenshot.png)

## 🛠️ Technologies Used
- Python 3
- Tkinter (GUI)
- Math module (for √ operations)

## 📦 Installation

### Run Locally
```bash
git clone https://github.com/Yallanti1939/AdvancedCalculator.git
cd AdvancedCalculator
python calculator.py
```

### Convert to .exe (Windows only)
Install `pyinstaller`:
```bash
pip install pyinstaller
```

Build executable:
```bash
pyinstaller --onefile --noconsole calculator.py
```

Find `.exe` in the `dist/` folder.

## 📄 Requirements
```
tkinter
```

_Tkinter comes pre-installed with most Python distributions._

## 👨‍💻 Author
- **Yallanti Venkata Sai Teja**
- GitHub: [@Yallanti1939](https://github.com/Yallanti1939)

## 📜 License
MIT License
