import tkinter as tk
import math

def click(event):
    global expression
    text = event.widget.cget("text")

    if text == "=":
        try:
            result = eval(expression.replace("^", "**").replace("√", "math.sqrt"))
            entry_var.set(result)
            history_list.insert(tk.END, expression + " = " + str(result))
            expression = str(result)
        except Exception as e:
            entry_var.set("Error")
            expression = ""
    elif text == "C":
        expression = ""
        entry_var.set("")
    else:
        expression += text
        entry_var.set(expression)

root = tk.Tk()
root.title("Advanced Calculator")
root.geometry("350x500")
root.resizable(0, 0)

expression = ""
entry_var = tk.StringVar()

entry = tk.Entry(root, textvar=entry_var, font="Arial 20", bd=10, relief=tk.SUNKEN, justify=tk.RIGHT)
entry.pack(fill=tk.BOTH, ipadx=8, pady=10, padx=10)

button_frame = tk.Frame(root)
button_frame.pack()

buttons = [
    ['7', '8', '9', '/'],
    ['4', '5', '6', '*'],
    ['1', '2', '3', '-'],
    ['C', '0', '=', '+'],
    ['√', '^', '%']
]

for row in buttons:
    row_frame = tk.Frame(button_frame)
    row_frame.pack(expand=True, fill='both')
    for btn_text in row:
        btn = tk.Button(row_frame, text=btn_text, font="Arial 18", relief=tk.RIDGE, border=1)
        btn.pack(side='left', expand=True, fill='both', padx=5, pady=5)
        btn.bind("<Button-1>", click)

history_label = tk.Label(root, text="History", font="Arial 14 bold")
history_label.pack(pady=(10, 0))

history_list = tk.Listbox(root, font="Arial 12", height=5)
history_list.pack(fill=tk.BOTH, padx=10, pady=(0, 10))

root.mainloop()